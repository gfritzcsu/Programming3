// Simple Program with a few Errors for Correction
// Please be sure to correct all outlined errors.


#include <iostream>
using namespace std;

// Main Function
int main()
{
    // Standard Output Statement
    cout << "Welcome to this C++ Program" << endl;

    cout << "I have corrected all errors for this program." << endl;

    // Main Function return Statement
    return 0;

}
